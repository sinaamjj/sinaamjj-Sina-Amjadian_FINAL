export default function Home() {
  return (
    <>
      <h1>Salam</h1>
    </>
  );
}
