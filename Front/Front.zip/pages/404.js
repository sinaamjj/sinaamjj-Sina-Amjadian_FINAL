/* eslint-disable react/jsx-no-undef */
/* eslint-disable @next/next/no-img-element */
/* eslint-disable jsx-a11y/alt-text */
import Image from "next/image";
import Link from "next/link";
import styles from "./404.module.css";
import errorTv from "../public/images/Error TV.png";

function notFound() {
  return (
    <>
      <div className={styles.container}>
        {/* LEFT (IMG) */}
        <div>
          <Image src={errorTv} alt="errorTv" />
        </div>
        {/* RIGHT */}
        <div>
          <h1>!صفحه مورد نظر یافت نشد</h1>
          <Link href="/">
            <button>بازگشت به صفحه اصلی</button>
          </Link>
        </div>
      </div>
    </>
  );
}

export default notFound;
