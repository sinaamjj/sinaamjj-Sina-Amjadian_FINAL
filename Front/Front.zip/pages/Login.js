import styles from "./Login.module.css";
import { useFormik } from "formik";
import * as Yup from "yup";
import axios from "axios";
import { toast } from "react-toastify";
import { useRouter } from "next/router";

function Login() {
  const router = useRouter();

  const validationSchema = Yup.object({
    phone: Yup.string()
      .required("شماره موبایل الزامی است")
      .test(
        "is-valid-phone",
        "شماره موبایل معتبر نیست",
        (value) => !value || /^09\d{9}$/.test(value)
      ),
  });

  const formik = useFormik({
    initialValues: {
      phone: "",
    },
    validationSchema,
    onSubmit: async (values) => {
      try {
        const response = await axios.post(
          "http://localhost:6500/auth/send-otp",
          {
            mobile: values.phone,
          }
        );

        console.log("پاسخ سرور:", response.data);
        toast.success("✅ کد تایید با موفقیت ارسال شد!");
      } catch (error) {
        console.error(
          "خطا در ارسال شماره:",
          error.response?.data || error.message
        );
        toast.error("❌ ارسال کد با خطا مواجه شد!");
      }
    },
  });

  return (
    <div className={styles.backDrop}>
      <form className={styles.container} onSubmit={formik.handleSubmit}>
        <button className={styles.closeBtn} onClick={() => router.back()}>
          X
        </button>

        <h1>ورود به تورینو</h1>
        <div className={styles.inputGroup}>
          <p>شماره موبایل خود را وارد کنید</p>
          <input
            type="text"
            name="phone"
            value={formik.values.phone}
            onChange={formik.handleChange}
            placeholder="2302***0912"
          />
        </div>
        {formik.touched.phone && formik.errors.phone && (
          <div className={styles.errorText}>{formik.errors.phone}</div>
        )}
        <button className={styles.btn} type="submit">
          ارسال کد تایید
        </button>
      </form>
    </div>
  );
}

export default Login;
