/* eslint-disable react/jsx-no-undef */
/* eslint-disable @next/next/no-img-element */
/* eslint-disable jsx-a11y/alt-text */
import Image from "next/image";

import styles from "./404.module.css";
import error from "../public/images/Error Lamp Robot.png";

function notFound() {
  return (
    <>
      <div className={styles.container}>
        {/* LEFT (IMG) */}
        <div>
          <Image src={error} alt="error" />
        </div>
        {/* RIGHT */}
        <div>
          <h1>!اتصال با سرور برقرار نیست</h1>
          <h2>.لطفا بعدا دوباره امتحان کنید</h2>
        </div>
      </div>
    </>
  );
}

export default notFound;
