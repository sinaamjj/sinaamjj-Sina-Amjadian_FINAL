/* eslint-disable @next/next/no-img-element */
/* eslint-disable jsx-a11y/alt-text */
import Link from "next/link";
import Image from "next/image";
import Frame from "../../public/images/Frame.png";
import StateAir from "../../public/images/state-airline-f45c55b2 1.png";
import Samandehi from "../../public/images/samandehi-6e2b448a.png";
import Aira from "../../public/images/aira-682b7c43.png";
import Ecunion from "../../public/images/ecunion-35c3c933.png";
import Passenger from "../../public/images/Passenger.png";
import styles from "./Layout.module.css";
function Layout({ children }) {
  return (
    <>
      {/* HEADER */}
      <header className={styles.header}>
        <div className={styles.container}>
          {/* LEFT */}
          <div className={styles.btnContainer}>
            <Link href="/Signup" className={styles.linkStyle}>
              <button className={styles.signup}>ثبت نام</button>
            </Link>
            <Link href="/Login" className={styles.linkStyle}>
              <button className={styles.login}>ورود</button>
              <Image src={Frame} alt="Frame" width={20} height={20} />
            </Link>
          </div>
          {/* MIDDLE */}
          <div className={styles.navbar}>
            <ul className={styles.ulStyle}>
              <li>تماس با ما</li>
              <li>درباره ما</li>
              <li>خدمات گردشگری</li>
              <li>صفحه اصلی</li>
            </ul>
          </div>
          {/* RIGHT */}
          <div>
            <Link href="/">
              <img src="/images/Torino (4) 1.png" alt="Torino" />
            </Link>
          </div>
        </div>
      </header>
      <div className={styles.children}>{children}</div>
      {/* FOOTER */}
      <footer className={styles.footer}>
        <div className={styles.topFooter}>
          {/* LEFT */}
          <div className={styles.leftFooter}>
            <div>
              <Link href="/">
                <img src="/images/Torino (4) 1.png" alt="Torino" />
              </Link>
            </div>
            <p>تلفن پشتیبانی : 4758-021</p>
            <div>
              <Image src={Aira} alt="Aria" className={styles.footerIcon} />
              <Image
                src={Samandehi}
                alt="Samandehi"
                className={styles.footerIcon}
              />
              <Image
                src={Ecunion}
                alt="Ecunion"
                className={styles.footerIcon}
              />
              <Image
                src={Passenger}
                alt="Passenger"
                className={styles.footerIcon}
              />
              <Image
                src={StateAir}
                alt="StateAir"
                className={styles.footerIcon}
              />
            </div>
          </div>
          {/* MIDDLE */}
          <div className={styles.middleFooter}>
            <ul className={styles.ulFooterStyle}>
              <h2>خدمات مشتریان</h2>
              <li>پشتیبانی آنلاین</li>
              <li>راهنمای خرید</li>
              <li>راهنمای استرداد</li>
              <li>پرسش و پاسخ</li>
            </ul>
          </div>
          {/* RIGHT */}
          <div className={styles.rightFooter}>
            <ul className={styles.ulFooterStyle}>
              <h2>تورینو</h2>
              <li>درباره ما</li>
              <li>تماس با ما</li>
              <li>چرا تورینو</li>
              <li>بیمه مسافرتی</li>
            </ul>
          </div>
        </div>
        {/* BOTTOM FOOTER */}
        <div className={styles.bottomFooter}>
          <p>.کلیه حقوق این وب سایت متعلق به تورینو میباشد</p>
        </div>
      </footer>
    </>
  );
}

export default Layout;
